"""Analyse des journaux du pare-feu : nettoyage, résultats, figures.

Usage : python analyse.py
"""
import json
import os

import matplotlib

matplotlib.use("Agg")  # pas d'affichage à l'écran, on enregistre seulement
import matplotlib.pyplot as plt
import pandas as pd

CHEMIN_DONNEES = "data/logs_reseau.csv"
DOSSIER_FIGURES = "figures"
FICHIER_RESULTATS = "resultats.json"


def nettoyer(df: pd.DataFrame) -> pd.DataFrame:
    """Supprime les doublons, normalise protocol, impute bytes_sent."""
    df = df.drop_duplicates().copy()
    df["protocol"] = df["protocol"].str.upper()
    # la médiane est calculée APRÈS suppression des doublons
    df["bytes_sent"] = df["bytes_sent"].fillna(df["bytes_sent"].median())
    df["timestamp"] = pd.to_datetime(df["timestamp"])
    return df.reset_index(drop=True)


def calculer_resultats(df: pd.DataFrame) -> dict:
    """Calcule les 5 résultats demandés."""
    return {
        "nb_lignes_apres_nettoyage": int(len(df)),
        "top_port": int(df["dst_port"].value_counts().idxmax()),
        "taux_deny_pct": round(float((df["action"] == "DENY").mean() * 100), 2),
        "ip_scanner": str(df.groupby("src_ip")["dst_port"].nunique().idxmax()),
        "ip_exfiltration": str(df.groupby("src_ip")["bytes_sent"].sum().idxmax()),
    }


def enregistrer(nom: str) -> None:
    plt.tight_layout()
    plt.savefig(os.path.join(DOSSIER_FIGURES, nom), dpi=120)
    plt.close()


def faire_figures(df: pd.DataFrame) -> None:
    os.makedirs(DOSSIER_FIGURES, exist_ok=True)

    # 1. Top 10 des ports de destination
    plt.figure(figsize=(8, 5))
    top = df["dst_port"].value_counts().head(10)
    top.index = top.index.astype(str)
    top.plot(kind="bar", color="steelblue")
    plt.title("Top 10 des ports de destination")
    plt.xlabel("Port de destination")
    plt.ylabel("Nombre de connexions")
    plt.xticks(rotation=0)
    enregistrer("top_ports.png")

    # 2. Répartition ALLOW / DENY
    plt.figure(figsize=(5, 5))
    df["action"].value_counts().plot(
        kind="pie", autopct="%1.1f%%", colors=["seagreen", "indianred"]
    )
    plt.title("Répartition des connexions ALLOW / DENY")
    plt.ylabel("")
    enregistrer("allow_deny.png")

    # 3. Connexions par jour
    plt.figure(figsize=(8, 5))
    par_jour = df.groupby(df["timestamp"].dt.date).size()
    par_jour.plot(kind="bar", color="darkorange")
    plt.title("Nombre de connexions par jour")
    plt.xlabel("Jour")
    plt.ylabel("Nombre de connexions")
    plt.xticks(rotation=45, ha="right")
    enregistrer("connexions_par_jour.png")

    # 4. Connexions par heure de la journée
    plt.figure(figsize=(9, 5))
    par_heure = df.groupby(df["timestamp"].dt.hour).size()
    par_heure.plot(kind="bar", color="slateblue")
    plt.title("Nombre de connexions par heure de la journée")
    plt.xlabel("Heure (0 à 23)")
    plt.ylabel("Nombre de connexions")
    plt.xticks(rotation=0)
    enregistrer("connexions_par_heure.png")

    # 5. Volume d'octets par type d'appareil (échelle log car très inégal)
    plt.figure(figsize=(7, 5))
    octets = df.groupby("device_type")["bytes_sent"].sum().sort_values()
    octets.plot(kind="barh", color="teal")
    plt.xscale("log")
    plt.title("Octets envoyés par type d'appareil (échelle log)")
    plt.xlabel("Total d'octets envoyés (échelle logarithmique)")
    plt.ylabel("Type d'appareil")
    enregistrer("octets_par_appareil.png")

    # 6. Top 10 des IP par volume d'octets (met en évidence l'exfiltration)
    plt.figure(figsize=(9, 5))
    top_ip = df.groupby("src_ip")["bytes_sent"].sum().nlargest(10) / 1e6
    top_ip.plot(kind="bar", color="firebrick")
    plt.title("Top 10 des IP sources par volume envoyé")
    plt.xlabel("Adresse IP source")
    plt.ylabel("Mégaoctets envoyés")
    plt.xticks(rotation=45, ha="right")
    enregistrer("top_ip_octets.png")

    # 7. Ports distincts contactés par IP (met en évidence le scan)
    plt.figure(figsize=(9, 5))
    ports_ip = df.groupby("src_ip")["dst_port"].nunique().nlargest(10)
    ports_ip.plot(kind="bar", color="purple")
    plt.title("Top 10 des IP par nombre de ports distincts contactés")
    plt.xlabel("Adresse IP source")
    plt.ylabel("Ports distincts")
    plt.xticks(rotation=45, ha="right")
    enregistrer("ports_distincts_par_ip.png")


def main() -> None:
    df = nettoyer(pd.read_csv(CHEMIN_DONNEES))
    resultats = calculer_resultats(df)
    with open(FICHIER_RESULTATS, "w", encoding="utf-8") as f:
        json.dump(resultats, f, indent=2, ensure_ascii=False)
    faire_figures(df)
    print("Résultats :", json.dumps(resultats, indent=2, ensure_ascii=False))
    print(f"Figures enregistrées dans {DOSSIER_FIGURES}/")


if __name__ == "__main__":
    main()
