# Projet 1 — Analyse des journaux d'un pare-feu

**Auteur : NOM Prénom** (à remplacer par ton nom et prénom)

## Lancer le projet

```bash
pip install -r requirements.txt
python analyse.py
```

Le script lit `data/logs_reseau.csv`, nettoie les données, écrit `resultats.json`
et enregistre les graphiques dans `figures/`. L'analyse et les recommandations
sont dans `rapport.md`.
