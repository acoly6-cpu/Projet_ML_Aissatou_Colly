# Rapport — Analyse des journaux du pare-feu

## Résumé
Le pare-feu a enregistré 5 500 lignes sur une semaine (du 5 au 11 octobre 2026) ; il en reste 5 440 après suppression de 60 doublons exacts. Le trafic normal est dominé par HTTPS (port 443, 1 874 connexions), HTTP (80) et DNS (53). 13,57 % des connexions sont bloquées (DENY). Deux comportements sortent nettement du lot : un scan de ports massif le 8 octobre et un transfert de données énorme depuis une caméra le 10 octobre. On observe aussi des tentatives régulières sur Telnet (23) et RDP (3389), presque toujours bloquées.

## Résultats chiffrés (`resultats.json`)
| Clé | Valeur |
|---|---|
| nb_lignes_apres_nettoyage | 5440 |
| top_port | 443 |
| taux_deny_pct | 13.57 |
| ip_scanner | 192.168.1.99 |
| ip_exfiltration | 192.168.1.11 |

## Comportement suspect 1 — Scan de ports depuis 192.168.1.99
- Cette IP (un « PC ») a contacté **328 ports distincts**, de 9 à 1023, tous sur la même cible 10.0.0.5. Les autres IP n'en contactent que 8 au maximum.
- **400 connexions en 15 minutes** (le 8 octobre entre 00:00 et 00:15), très courtes (0,05 s en moyenne) et petites (100 octets en moyenne). **383 sur 400 ont été bloquées (DENY)**, mais 17 ont été autorisées : ces ports ouverts sont désormais connus de l'attaquant.
- Preuves : `figures/ports_distincts_par_ip.png` (192.168.1.99 écrase toutes les autres IP), `figures/connexions_par_heure.png` (pic à minuit : 610 connexions contre environ 200 pour les autres heures) et `figures/connexions_par_jour.png` (le 8 octobre compte 1 137 connexions contre environ 700 les autres jours).
- Interprétation : un poste interne (probablement compromis, ou utilisé pour de la reconnaissance) cartographie les services ouverts du réseau avant une attaque.

## Comportement suspect 2 — Exfiltration de données depuis la caméra 192.168.1.11
- Cette caméra IoT a envoyé **environ 260 Mo** au total, soit **94 % de tout le volume du réseau** (274,6 Mo). Aucune autre IP ne dépasse 0,7 Mo.
- Cela vient de **38 gros transferts (plus de 1 Mo, jusqu'à 8,7 Mo chacun)** vers l'IP externe **8.8.8.8 sur le port 8080**, répartis sur toute la journée du 10 octobre (de 00:08 à 23:53), tous **autorisés (ALLOW)**. Le reste de son activité est normal (médiane d'environ 2 Ko par connexion).
- Preuves : `figures/top_ip_octets.png` et `figures/octets_par_appareil.png` (les caméras IoT pèsent 262 Mo contre 1 à 7 Mo pour les autres types).
- Interprétation : une caméra n'a aucune raison d'envoyer des mégaoctets vers Internet sur un port 8080. Elle est probablement compromise et sert à sortir des données (ou des images) vers l'extérieur.

## Autres observations
- Telnet (port 23), protocole non chiffré et obsolète : 100 tentatives, dont 74 bloquées, venant de 29 IP internes différentes, y compris des caméras et des capteurs.
- RDP (port 3389) : 111 connexions, dont 81 bloquées, venant d'appareils très variés.

## Recommandations de sécurité
1. **Bloquer l'envoi sortant de la caméra 192.168.1.11** et l'isoler du réseau, puis analyser et réinitialiser l'appareil (mot de passe par défaut, firmware).
2. **Filtrer le trafic sortant** : par défaut tout refuser, et n'autoriser que les destinations et ports nécessaires (443, 53 vers les DNS de l'entreprise). Bloquer le port 8080 vers Internet et surveiller les transferts volumineux (alerte au-delà de quelques Mo par connexion).
3. **Segmenter le réseau** : placer les objets IoT (caméras, capteurs) dans un VLAN séparé, sans accès aux serveurs ni à Internet, sauf flux explicitement autorisés (par exemple MQTT 1883 vers un seul serveur interne).
4. **Fermer Telnet (23) partout** et le remplacer par SSH ; limiter RDP (3389) à un VPN ou à une liste d'IP d'administration.
5. **Mettre en place une détection automatique de scan** : alerte et blocage temporaire d'une IP qui touche plus de 20 ports distincts en quelques minutes. Isoler et vérifier le poste 192.168.1.99.
6. **Surveiller régulièrement les journaux** (SIEM ou alertes simples) pour repérer les pics d'activité à des heures inhabituelles.
